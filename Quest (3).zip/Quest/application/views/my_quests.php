<h3 class="h5 fw-bold mb-3">🛡️ My Accepted Quests</h3>

<?php if(empty($accepted_quests)): ?>
  <div class="card border-0 shadow-sm p-4 rounded-3 text-center bg-white">
    <p class="text-secondary m-0">You haven't accepted any quests yet.</p>
  </div>
<?php else: ?>
  <div class="row g-3">
    <?php foreach($accepted_quests as $quest): ?>
      <div class="col-md-6">
        <div class="card border-0 shadow-sm p-3 rounded-3 bg-white">
          <div class="d-flex justify-content-between align-items-start mb-2">
            <h4 class="h6 fw-bold m-0 text-dark"><?php echo html_escape($quest['title']); ?></h4>
            <span class="badge bg-primary">In Progress</span>
          </div>
          <p class="text-secondary small mb-3"><?php echo html_escape($quest['description']); ?></p>
          <div class="fw-bold text-success">Reward: ₱<?php echo number_format($quest['reward'], 2); ?></div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

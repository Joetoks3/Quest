<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo isset($title) ? $title . " - Utosmation" : "Utosmation"; ?></title>
  <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>">

  <!-- Alertify.js CSS -->
  <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/alertify.min.css"/>
  <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/themes/bootstrap.min.css"/>
</head>
<body class="bg-light">

  <!-- Navigation Bar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top shadow-sm">
    <div class="container-fluid">
      <a class="navbar-brand fw-bold px-2" href="#">Utosmation</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#topNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      
      <div class="collapse navbar-collapse" id="topNavbar">
        <ul class="navbar-link navbar-nav ms-auto mb-2 mb-lg-0 align-items-lg-center">
          <li class="nav-item">
            <a class="nav-link" href="#">Notifications</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown">
              User Account
            </a>
            <ul class="dropdown-menu dropdown-menu-end shadow">
              <li><a class="dropdown-item" href="#">Profile Settings</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item text-danger" href="<?php echo site_url('questcontroller/index'); ?>">Logout</a></li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Sidebar & Grid Container -->
  <div class="container-fluid">
    <div class="row">

      <!-- Navigation Sidebar -->
      <nav class="col-md-3 col-lg-2 d-md-block bg-white sidebar border-end min-vh-100 py-3">
        <div class="position-sticky">
          <ul class="nav nav-pills flex-column gap-1">
            <li class="nav-item">
              <a href="<?php echo site_url('questcontroller/home'); ?>" class="nav-link <?php echo ($this->uri->segment(2) == 'home') ? 'active' : 'link-dark'; ?>">Quests Board</a>
            </li>
            <li class="nav-item">
              <a href="<?php echo site_url('questcontroller/my_quests'); ?>" class="nav-link <?php echo ($this->uri->segment(2) == 'my_quests') ? 'active' : 'link-dark'; ?>">My Accepted Quests</a>
            </li>
            <li class="nav-item">
              <a href="<?php echo site_url('questcontroller/history'); ?>" class="nav-link <?php echo ($this->uri->segment(2) == 'history') ? 'active' : 'link-dark'; ?>">Quest History</a>
            </li>
            <li class="nav-item">
              <a href="#" class="nav-link link-dark">Placeholder</a>
            </li>
          </ul>
        </div>
      </nav>

      <!-- Main Layout Body Section Injection -->
      <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">

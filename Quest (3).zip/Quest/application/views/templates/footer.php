      </main> <!-- Closes the active page container grid item -->

    </div>
  </div>

  <!-- Framework Dependencies Core Scripts -->
  <script src="<?php echo base_url('assets/js/bootstrap.bundle.min.js'); ?>"></script>
  <script src="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>
  
  <script type="text/javascript">
    // Configure default Alertify layout position
    alertify.set('notifier', 'position', 'top-right');

    // Intercept CodeIgniter success tracking messages
    <?php if($this->session->flashdata('success')): ?>
        alertify.success("<?php echo $this->session->flashdata('success'); ?>");
    <?php endif; ?>

    // Intercept CodeIgniter form validation constraints
    <?php if($this->session->flashdata('error')): ?>
        let validationErrors = `<?php echo trim(preg_replace('/\s+/', ' ', $this->session->flashdata('error'))); ?>`;
        alertify.error(validationErrors);
    <?php endif; ?>
  </script>
</body>
</html>

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class QuestController extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }

    // Default route / index view
    public function index() {
        $this->load->view('index');
    }

    public function home() {
        $data['title'] = "Quests Board"; // Dynamic title passed to header view
        $data['quests'] = $this->QuestModel->get_active_quests();
        
        // Sequentially load elements to render the complete page
        $this->load->view('templates/header', $data);
        $this->load->view('home', $data);
        $this->load->view('templates/footer');
    }


    public function my_quests() {
        $user_id = 1; // Replace with session user_id when authentication is added
        $data['title'] = "My Accepted Quests"; // Dynamic title passed to header view
        $data['accepted_quests'] = $this->QuestModel->get_accepted_quests($user_id);
        
        // Sequentially load elements to render the complete page
        $this->load->view('templates/header', $data);
        $this->load->view('my_quests', $data);
        $this->load->view('templates/footer');
    }

    // Post a new quest with Form Validation
    public function create_quest() {
        // Set validation rules: field_name, Human Label, rules
        $this->form_validation->set_rules('title', 'Quest Title', 'required|min_length[5]');
        $this->form_validation->set_rules('description', 'Description', 'required|min_length[10]');
        $this->form_validation->set_rules('reward', 'Reward', 'required|numeric|greater_than[0]');

        if ($this->form_validation->run() == FALSE) {
            // Validation failed: Send specific validation errors to Alertify
            $this->session->set_flashdata('error', validation_errors(' ', ' '));
            redirect('QuestController/home');
        } else {
            // Validation passed: Insert to DB
            $data = array(
                'title'       => $this->input->post('title'),
                'description' => $this->input->post('description'),
                'reward'      => $this->input->post('reward'),
                'status'      => 'open'
            );

            if ($this->QuestModel->insert_quest($data)) {
                $this->session->set_flashdata('success', 'Quest posted successfully!');
            } else {
                $this->session->set_flashdata('error', 'Failed to post quest.');
            }

            redirect('QuestController/home');
        }
    }

    // Edit quest details with Form Validation
    public function edit_quest($id) {
        $this->form_validation->set_rules('title', 'Quest Title', 'required|min_length[5]');
        $this->form_validation->set_rules('description', 'Description', 'required|min_length[10]');
        $this->form_validation->set_rules('reward', 'Reward', 'required|numeric|greater_than[0]');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors(' ', ' '));
            redirect('QuestController/home');
        } else {
            $data = array(
                'title'       => $this->input->post('title'),
                'description' => $this->input->post('description'),
                'reward'      => $this->input->post('reward')
            );

            if ($this->QuestModel->update_quest($id, $data)) {
                $this->session->set_flashdata('success', 'Quest updated successfully!');
            } else {
                $this->session->set_flashdata('error', 'Failed to update quest.');
            }

            redirect('QuestController/home');
        }
    }

    // Delete a quest
    public function delete_quest($id) {
        if ($this->QuestModel->delete_quest($id)) {
            $this->session->set_flashdata('success', 'Quest deleted successfully!');
        } else {
            $this->session->set_flashdata('error', 'Failed to delete quest.');
        }

        redirect('QuestController/home');
    }

    // Accept an open quest
    public function accept_quest($id) {
        $user_id = 1; 

        if ($this->QuestModel->accept_quest($id, $user_id)) {
            $this->session->set_flashdata('success', 'Quest accepted successfully!');
        } else {
            $this->session->set_flashdata('error', 'Unable to accept quest.');
        }

        redirect('QuestController/my_quests');
    }

    // Complete a quest
    public function complete_quest($id) {
        $user_id = 1; 

        if ($this->QuestModel->complete_quest($id, $user_id)) {
            $this->session->set_flashdata('success', '🎉 Quest marked as completed!');
        } else {
            $this->session->set_flashdata('error', 'Unable to complete the quest.');
        }

        redirect('QuestController/home');
    }

   public function history() {
    $user_id = 1; 
    $data['title'] = "Quest History"; // Dynamically sets the template title
    $data['completed_quests'] = $this->QuestModel->get_completed_quests($user_id);

    $this->load->view('templates/header', $data);
    $this->load->view('history', $data);
    $this->load->view('templates/footer');
    }
}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class QuestController extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('QuestModel');
        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->library('session');
    }

    // Default route / index view
    public function index() {
        $this->home();
    }

    // Single home() method for the Quests Board
    public function home() {
        $data['quests'] = $this->QuestModel->get_active_quests();
        $this->load->view('home', $data);
    }

    // View for My Accepted Quests
    public function my_quests() {
        $user_id = 1; // Replace with session user_id when authentication is added
        $data['accepted_quests'] = $this->QuestModel->get_accepted_quests($user_id);
        $this->load->view('my_quests', $data);
    }

    // Post a new quest
    public function create_quest() {
        $data = array(
            'title'       => $this->input->post('title'),
            'description' => $this->input->post('description'),
            'reward'      => $this->input->post('reward'),
            'status'      => 'open'
        );

        if ($this->QuestModel->insert_quest($data)) {
            $this->session->set_flashdata('success', 'Quest posted successfully!');
        } else {
            $this->session->set_flashdata('error', 'Failed to post quest.');
        }

        redirect('QuestController/home');
    }

    // Edit quest details
    public function edit_quest($id) {
        $data = array(
            'title'       => $this->input->post('title'),
            'description' => $this->input->post('description'),
            'reward'      => $this->input->post('reward')
        );

        if ($this->QuestModel->update_quest($id, $data)) {
            $this->session->set_flashdata('success', 'Quest updated successfully!');
        } else {
            $this->session->set_flashdata('error', 'Failed to update quest.');
        }

        redirect('QuestController/home');
    }

    // Delete a quest
    public function delete_quest($id) {
        if ($this->QuestModel->delete_quest($id)) {
            $this->session->set_flashdata('success', 'Quest deleted successfully!');
        } else {
            $this->session->set_flashdata('error', 'Failed to delete quest.');
        }

        redirect('QuestController/home');
    }

    // Accept an open quest
    public function accept_quest($id) {
        $user_id = 1; 

        if ($this->QuestModel->accept_quest($id, $user_id)) {
            $this->session->set_flashdata('success', 'Quest accepted successfully!');
        } else {
            $this->session->set_flashdata('error', 'Unable to accept quest.');
        }

        redirect('QuestController/my_quests');
    }

    // Complete a quest
    public function complete_quest($id) {
        $user_id = 1; 

        if ($this->QuestModel->complete_quest($id, $user_id)) {
            $this->session->set_flashdata('success', '🎉 Quest marked as completed!');
        } else {
            $this->session->set_flashdata('error', 'Unable to complete the quest.');
        }

        redirect('QuestController/home');
    }
}
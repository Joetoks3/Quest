<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login</title>
		<link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>">
	

</head>
<body>
	
	<div class="d-flex flex-column justify-content-center align-items-center min-vh-100 text-center">
		<div class="bg-white p-5 rounded-4 shadow text-center">
		<h1>Welcome to Utosmation!</h1>
		<a href="<?php echo site_url('QuestController/home'); ?>" class="btn btn-primary mt-3">Enter</a>
		</div>
	</div>

	<script src="<?php echo base_url('assets/js/bootstrap.bundle.min.js'); ?>"></script>
</body>
</html>
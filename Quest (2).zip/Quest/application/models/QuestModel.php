<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class QuestModel extends CI_Model {

    public function get_open_quests() {
        return $this->db->where('status', 'open')
                        ->order_by('id', 'DESC')
                        ->get('quests')
                        ->result_array();
    }

    public function get_quest($id) {
        return $this->db->get_where('quests', ['id' => $id])->row_array();
    }

    public function insert_quest($data) {
        return $this->db->insert('quests', $data);
    }

    public function update_quest($id, $data) {
        $this->db->where('id', $id);
        return $this->db->update('quests', $data);
    }

    public function delete_quest($id) {
        return $this->db->delete('quests', array('id' => $id));
    }

    // Mark quest as accepted by a specific user
    public function accept_quest($quest_id, $user_id) {
        $data = array(
            'status'      => 'accepted',
            'accepted_by' => $user_id
        );
        $this->db->where('id', $quest_id);
        $this->db->where('status', 'open'); // Prevents double-claiming
        return $this->db->update('quests', $data);
    }

    // Retrieve all in-progress quests
    public function get_accepted_quests($user_id = null) {
        $this->db->where('status', 'accepted');
        if ($user_id !== null) {
            $this->db->where('accepted_by', $user_id);
        }
        return $this->db->order_by('id', 'DESC')
                        ->get('quests')
                        ->result_array();
    }

    // Complete method matching the call in QuestController
    public function complete_quest($quest_id, $user_id = null) {
        $data = array('status' => 'completed');
        $this->db->where('id', $quest_id);
        $this->db->where('status', 'accepted'); // MUST be in progress first
        return $this->db->update('quests', $data);
    }

    // Alias for completion
    public function complete_accepted_quest($quest_id) {
        return $this->complete_quest($quest_id);
    }

    // Fetch both open and accepted quests so posters can see in-progress work
    public function get_active_quests() {
        return $this->db->where_in('status', ['open', 'accepted'])
                        ->order_by('id', 'DESC')
                        ->get('quests')
                        ->result_array();
    }

    // Retrieve completed quests for history
    public function get_completed_quests($user_id = null) {
        $this->db->where('status', 'completed');
        if ($user_id !== null) {
            $this->db->where('accepted_by', $user_id);
        }
        return $this->db->order_by('id', 'DESC')
                        ->get('quests')
                        ->result_array();
    }
}
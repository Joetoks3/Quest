<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Quest History - Utosmation</title>
  <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>">
</head>
<body class="bg-light">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top shadow-sm">
    <div class="container-fluid">
      <a class="navbar-brand fw-bold px-2" href="#">Utosmation</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#topNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      
      <div class="collapse navbar-collapse" id="topNavbar">
        <ul class="navbar-link navbar-nav ms-auto mb-2 mb-lg-0 align-items-lg-center">
          <li class="nav-item"><a class="nav-link active" href="#">Notifications</a></li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown">User Account</a>
            <ul class="dropdown-menu dropdown-menu-end shadow">
              <li><a class="dropdown-item" href="#">Profile Settings</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item text-danger" href="<?php echo site_url('QuestController/index'); ?>">Logout</a></li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <div class="container-fluid">
    <div class="row">

      <!-- Sidebar -->
      <nav class="col-md-3 col-lg-2 d-md-block bg-white sidebar border-end min-vh-100 py-3">
        <div class="position-sticky">
          <ul class="nav nav-pills flex-column gap-1">
            <li class="nav-item">
              <a href="<?php echo site_url('QuestController/home'); ?>" class="nav-link link-dark">Quests Board</a>
            </li>
            <li class="nav-item">
              <a href="<?php echo site_url('QuestController/my_quests'); ?>" class="nav-link link-dark">My Accepted Quests</a>
            </li>
            <li class="nav-item">
              <a href="<?php echo site_url('QuestController/history'); ?>" class="nav-link active">Quest History</a>
            </li>
            <li class="nav-item">
              <a href="#" class="nav-link link-dark">Placeholder</a>
            </li>
          </ul>
        </div>
      </nav>

      <!-- Main Content -->
      <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
        <h3 class="h5 fw-bold mb-3">📜 Quest History</h3>

        <?php if(empty($completed_quests)): ?>
          <div class="card border-0 shadow-sm p-4 rounded-3 text-center bg-white">
            <p class="text-secondary m-0">No completed quests in your history yet.</p>
          </div>
        <?php else: ?>
          <div class="row g-3">
            <?php foreach($completed_quests as $quest): ?>
              <div class="col-md-6">
                <div class="card border-0 shadow-sm p-3 rounded-3 bg-white">
                  <div class="d-flex justify-content-between align-items-start mb-2">
                    <h4 class="h6 fw-bold m-0 text-dark"><?php echo html_escape($quest['title']); ?></h4>
                    <span class="badge bg-success">✅ Completed</span>
                  </div>
                  <p class="text-secondary small mb-3"><?php echo html_escape($quest['description']); ?></p>
                  <div class="fw-bold text-success">Earned: ₱<?php echo number_format($quest['reward'], 2); ?></div>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </main>

    </div>
  </div>

  <script src="<?php echo base_url('assets/js/bootstrap.bundle.min.js'); ?>"></script>
</body>
</html>
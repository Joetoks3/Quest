<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Dashboard - Utosmation</title>
  <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>">

  <!-- Alertify.js CSS -->
  <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/alertify.min.css"/>
  <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/themes/bootstrap.min.css"/>
</head>
<body class="bg-light">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top shadow-sm">
    <div class="container-fluid">
      <a class="navbar-brand fw-bold px-2" href="#">Utosmation</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#topNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      
      <div class="collapse navbar-collapse" id="topNavbar">
        <ul class="navbar-link navbar-nav ms-auto mb-2 mb-lg-0 align-items-lg-center">
          <li class="nav-item">
            <a class="nav-link active" href="#">Notifications</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown">
              User Account
            </a>
            <ul class="dropdown-menu dropdown-menu-end shadow">
              <li><a class="dropdown-item" href="#">Profile Settings</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item text-danger" href="<?php echo site_url('QuestController/index'); ?>">Logout</a></li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Main Sidebar & Content Container -->
  <div class="container-fluid">
    <div class="row">

      <!-- Sidebar -->
      <nav class="col-md-3 col-lg-2 d-md-block bg-white sidebar border-end min-vh-100 py-3">
        <div class="position-sticky">
          <ul class="nav nav-pills flex-column gap-1">
            <li class="nav-item">
              <a href="<?php echo site_url('QuestController/home'); ?>" class="nav-link active">Quests Board</a>
            </li>
            <li class="nav-item">
              <a href="<?php echo site_url('QuestController/my_quests'); ?>" class="nav-link link-dark">My Accepted Quests</a>
            </li>
            <li class="nav-item">
              <a href="<?php echo site_url('QuestController/history'); ?>" class="nav-link link-dark">Quest History</a>
            </li>
            <li class="nav-item">
              <a href="#" class="nav-link link-dark">Placeholder</a>
            </li>
          </ul>
        </div>
      </nav>

      <!-- Main Content Area -->
      <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
        <div class="row">

          <!-- Left Column: Post a Quest Form (INSERT) -->
          <div class="col-lg-4 mb-4">
            <div class="card border-0 shadow-sm p-4 rounded-3 bg-white">
              <h3 class="h5 fw-bold mb-3">📜 Post a New Quest</h3>
              
              <?php echo form_open('QuestController/create_quest'); ?>
                <div class="mb-3">
                  <label class="form-label text-secondary fw-semibold">Quest Title</label>
                  <input type="text" name="title" class="form-control" placeholder="e.g., Buy coffee at Ayala Centrio" required>
                </div>
                
                <div class="mb-3">
                  <label class="form-label text-secondary fw-semibold">Description</label>
                  <textarea name="description" class="form-control" rows="3" placeholder="Describe the task details..." required></textarea>
                </div>
                
                <div class="mb-3">
                  <label class="form-label text-secondary fw-semibold">Reward (₱)</label>
                  <input type="number" step="0.01" name="reward" class="form-control" placeholder="150.00" required>
                </div>
                
                <input type="submit" name="submit" class="btn btn-primary w-100 fw-bold" value="Post Quest">
              <?php echo form_close(); ?>
            </div>
          </div>

          <!-- Right Column: Quest Cards (FETCH, ACCEPT, EDIT, DELETE, COMPLETE) -->
          <div class="col-lg-8">
            <div class="d-flex justify-content-between align-items-center mb-3">
              <h3 class="h5 fw-bold m-0">⚔️ Quests Board</h3>
              <span class="badge bg-secondary"><?php echo count($quests ?? []); ?> Active</span>
            </div>

            <?php if(empty($quests)): ?>
              <div class="card border-0 shadow-sm p-4 rounded-3 text-center bg-white">
                <p class="text-secondary m-0">No active quests right now. Post one on the left to get started!</p>
              </div>
            <?php else: ?>
              <div class="row g-3">
                <?php foreach($quests as $quest): ?>
                  <div class="col-md-6">
                    <div class="card border-0 shadow-sm h-100 p-3 rounded-3 bg-white d-flex flex-column justify-content-between">
                      <div>
                        <div class="d-flex justify-content-between align-items-start mb-2">
                          <h4 class="h6 fw-bold m-0 text-dark"><?php echo html_escape($quest['title']); ?></h4>
                          <span class="badge bg-success">₱<?php echo number_format($quest['reward'], 2); ?></span>
                        </div>
                        <p class="text-secondary small mb-3">
                          <?php echo html_escape($quest['description']); ?>
                        </p>
                      </div>

                      <!-- Actions logic based on Quest Status -->
                      <div class="d-flex gap-2 pt-2 border-top align-items-center">
                        <?php if ($quest['status'] == 'open'): ?>
                          
                          <!-- Open Status: Allow user to Accept, or Poster to Edit/Delete -->
                          <a href="<?php echo site_url('QuestController/accept_quest/' . $quest['id']); ?>" 
                             class="btn btn-success btn-sm fw-bold flex-grow-1"
                             onclick="return confirm('Do you want to accept this quest?');">
                            ⚔️ Accept
                          </a>

                          <button type="button" class="btn btn-warning btn-sm fw-bold" data-bs-toggle="modal" data-bs-target="#editModal<?php echo $quest['id']; ?>">
                            Edit
                          </button>

                          <a href="<?php echo site_url('QuestController/delete_quest/' . $quest['id']); ?>" 
                             class="btn btn-outline-danger btn-sm fw-bold" 
                             onclick="return confirm('Are you sure you want to delete this quest?');">
                            Delete
                          </a>

                        <?php elseif ($quest['status'] == 'accepted'): ?>

                          <!-- Accepted Status: Show In Progress badge & Poster Complete Button -->
                          <span class="badge bg-info text-dark fw-bold py-2 px-2">In Progress</span>

                          <a href="<?php echo site_url('QuestController/complete_quest/' . $quest['id']); ?>" 
                             class="btn btn-primary btn-sm fw-bold flex-grow-1"
                             onclick="return confirm('Verify work done and mark quest as completed?');">
                            ✅ Complete & Pay
                          </a>

                        <?php endif; ?>
                      </div>
                    </div>
                  </div>

                  <!-- Edit Modal for each quest -->
                  <div class="modal fade" id="editModal<?php echo $quest['id']; ?>" tabindex="-1" aria-labelledby="editModalLabel<?php echo $quest['id']; ?>" aria-hidden="true">
                    <div class="modal-dialog">
                      <div class="modal-content">
                        <?php echo form_open('QuestController/edit_quest/' . $quest['id']); ?>
                          <div class="modal-header">
                            <h5 class="modal-title fw-bold" id="editModalLabel<?php echo $quest['id']; ?>">Edit Quest</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <div class="modal-body">
                            <div class="mb-3">
                              <label class="form-label text-secondary fw-semibold">Quest Title</label>
                              <input type="text" name="title" class="form-control" value="<?php echo html_escape($quest['title']); ?>" required>
                            </div>
                            <div class="mb-3">
                              <label class="form-label text-secondary fw-semibold">Description</label>
                              <textarea name="description" class="form-control" rows="3" required><?php echo html_escape($quest['description']); ?></textarea>
                            </div>
                            <div class="mb-3">
                              <label class="form-label text-secondary fw-semibold">Reward (₱)</label>
                              <input type="number" step="0.01" name="reward" class="form-control" value="<?php echo $quest['reward']; ?>" required>
                            </div>
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-success fw-bold">Save Changes</button>
                          </div>
                        <?php echo form_close(); ?>
                      </div>
                    </div>
                  </div>
                <?php endforeach; ?>
              </div>
            <?php endif; ?>
          </div>

        </div>
      </main>

    </div>
  </div>

  <!-- JavaScript Files -->
  <script src="<?php echo base_url('assets/js/bootstrap.bundle.min.js'); ?>"></script>
  <script src="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>

  <!-- Alertify Toast Notifications Trigger -->
  <script>
    alertify.set('notifier','position', 'top-right');

    <?php if($this->session->flashdata('success')): ?>
      alertify.success(<?php echo json_encode($this->session->flashdata('success')); ?>);
    <?php endif; ?>

    <?php if($this->session->flashdata('error')): ?>
      alertify.error(<?php echo json_encode($this->session->flashdata('error')); ?>);
    <?php endif; ?>
  </script>

</body>
</html>